// Cria uma constante chamada... que armazena o resultado do processamento de uma função anônima do
// arrow function, que recebe o el como parâmetro, e que retorna o document.querySelector(variável do parâmetro)
const c = (el)=> document.querySelector(el);
const cs = (el)=> document.querySelectorAll(el);
// O nome da variável chama o método map para mapear, recebendo o item e o index como parâmetros
pizzaJson.map((item, index)=> {
	// Declara uma variável através da palavra-chave reservada let
	// que armazena o processamento de: no documento, chama o método querySelector
	// document.querySelector(envia o parâmetro que é o nome de uma div ou algumas divs)
	// Para clonar: cloneNode
	let pizzaItem = c('.models .pizza-item').cloneNode(true);

	//pizzaItem.querySelector('.pizza-item--name').innerHTML = item.name;

	// O método innerHTML substitui. O método append adiciona
	c('.pizza-area').append(pizzaItem);
		});

